require('rjson')
library(dplyr)

iris.json <- toJSON(iris)

write(iris.json,file='iris.json')

raw.data <- fromJSON(file='iris.json')

iris_data <- as.data.frame(raw.data)

#Select
select(iris_data,Sepal.Length:Petal.Width)

#match
select(iris_data,contains("Sepal"))

#filter
filter(iris_data, Sepal.Length > 6.7)

#arrange
arrange(iris_data, desc(Sepal.Length), Sepal.Width)

#rename
rename(iris_data, Petal_Width = Petal.Width)

#mutate
mutate(iris_data, Sepal.Area = Sepal.Length/Sepal.Width)
