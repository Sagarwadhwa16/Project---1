require('rjson')

iris.json <- toJSON(iris)

write(iris.json,file='iris.json')

raw.data <- fromJSON(file='iris.json')

iris_data <- as.data.frame(raw.data)

summary(iris_data)
