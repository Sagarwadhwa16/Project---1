#Iris.xml was not available. Hence the same solution is illustrated with a different .xml file

setwd("~/Assignmentss/Project 1")
require('XML')
library("methods")

df <- xmlToDataFrame("sample.xml")
print(df)
