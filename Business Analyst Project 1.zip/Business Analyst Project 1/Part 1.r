
setwd("~/Assignmentss/Project 1/iris")
filepath<-list.files(getwd(),".dat")
filepath
df=lapply(filepath, read.delim)
View(df)

